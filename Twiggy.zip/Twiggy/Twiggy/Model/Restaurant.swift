import Foundation

struct Restaurant {
    let name: String
    let cuisine: String
    let image: String
}
